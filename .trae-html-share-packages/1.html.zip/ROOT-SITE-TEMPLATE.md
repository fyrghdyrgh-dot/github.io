# 根站模板架构

这套根站模板用于生成 `fyrghdyrgh-dot.github.io` 这类目录站，目标是：

- 首页负责聚合分类与入口
- 分类页负责承接较宽泛的主题词
- 子页面负责承接更具体的搜索词
- 服务器相关页面的主外链统一指向 `https://www.1bgp.com/`
- 卡片信息分层展示，优先突出标题、标签和简要简介
- 每个分类默认补足到至少 5 个页面，方便后续继续扩展到 5 到 10 个

## 当前结构

- 首页：`/`
- 分类页：`/{category-slug}/`
- 子页面：`/{page-slug}/`
- 静态资源：`/assets/base.css`、`/assets/home.css`、`/assets/hub.css`、`/assets/detail.css`、`/assets/site.js`

## 数据源

- 配置文件：`root-site.config.mjs`
- 生成脚本：`scripts/build-root-site.mjs`
- 输出目录：`root-home-site/`

## 仓库与链接

- 模板源码仓库：`https://github.com/fyrghdyrgh-dot/github.io`
- 当前本地工作区：`/workspace`
- 根站发布仓库：`https://github.com/fyrghdyrgh-dot/fyrghdyrgh-dot.github.io`
- 根站访问地址：`https://fyrghdyrgh-dot.github.io/`

后续如果继续按模板生成：

1. 先在模板源码仓库里维护 `root-site.config.mjs` 和 `scripts/build-root-site.mjs`
2. 在本地运行 `npm run build:root-site`
3. 把生成后的 `root-home-site/` 发布到根站发布仓库
4. 最终外网访问地址仍然是 `https://fyrghdyrgh-dot.github.io/`

## 分类层

当前模板内置这些主分类：

- 网络与开发工具
- 中文 AI 工具专题
- 越南语 AI 专题
- 服务器与 IDC
- 开发与编程
- 知识与文档
- 客服与用户运营
- 电商与产品内容
- 翻译与语言处理
- 数据处理
- 教育与学习

每个分类包含：

- `slug`
- `name`
- `english`
- `summary`
- `intro`
- `hubStyle`
- `theme`

## 页面模板

当前生成器支持 4 类子页面：

- `tool`
  - 适合浏览器内工具、输入输出示例、检查流程
  - 通过 `detail.css` 输出工具型详情结构
- `guide`
  - 适合步骤型页面、清单页、操作说明页
  - 通过 `detail.css` 输出步骤型详情结构
- `service`
  - 适合服务器、IDC、方案咨询和购买引导页
  - 通过 `detail.css` 输出专题型详情结构
- `article`
  - 适合知识文档、教育学习、结构说明类页面
  - 通过 `detail.css` 输出文章型详情结构

## 当前容量

- 主分类：11 个
- 内容页：55 个
- 默认规则：每个分类至少 5 个内容页
- 后续目标：按流量词和业务词继续补到 5 到 10 个

## 视觉层

为了避免所有页面都长得一样，模板做了两层差异化：

- 分类层差异
  - 每个分类有自己的 `theme`
  - 分类页按“本类分区 + 卡片列表”结构输出
- 页面层差异
  - 不同 `type` 输出不同内容块
  - 同一分类内页面共享版式，但颜色、标签和内容重点不同
  - 卡片层级固定为：标题 -> 标签 -> 分类 -> 简介 -> 关键信息 -> 动作按钮

## SEO 结构

生成器会自动输出：

- `canonical`
- `robots` / `googlebot` / `baiduspider`
- `og:title`
- `og:description`
- `twitter:card`
- `twitter:title`
- `twitter:description`
- 首页和分类页的 `CollectionPage` 结构化数据
- 分类页与详情页的 `BreadcrumbList`
- 分类页的 `ItemList`
- 子页的 `WebPage` 或 `Article` 结构化数据
- FAQ 页的 `FAQPage`
- `robots.txt`
- `sitemap.xml`
- `site-manifest.json`
- `sitemap.xml` 中的 `lastmod`

这些优化能把站点做到“更容易被 Google 和百度抓取与理解”的程度，但是否实际收录仍取决于：

- 页面上线后的抓取周期
- 是否持续新增内容
- 是否有稳定内链和外链
- 是否在 Google Search Console / 百度搜索资源平台中提交站点

## 服务器外链规则

- 服务器相关页面的主转化外链统一为 `https://www.1bgp.com/`
- 该规则在 `root-site.config.mjs` 的 `site.serverTarget` 中集中维护
- 后续扩展服务器类页面时，不要写成分散的多个主域名

## 扩展方式

后续如果你要继续新增几十个页面，优先按下面方式扩展：

1. 在 `root-site.config.mjs` 里新增分类，或向现有分类追加页面
2. 保持每个分类至少 5 个页面，再继续扩充到 5 到 10 个
3. 为新页面指定 `type`
4. 补充页面标题、摘要、关键词和相关链接
5. 保持卡片摘要简短，不要把标题和长文案堆在同一区域
6. 运行：

```bash
npm run build:root-site
```

7. 发布 `root-home-site/` 到根站仓库

## 模板状态

- 模板已做完，当前模板源文件就是 `root-site.config.mjs` + `scripts/build-root-site.mjs`
- 这套模板已经支持批量扩分类、扩页面数量、统一生成首页/分类页/详情页
- 后续如果要再批量做几十页，优先在配置里继续追加页面，不要手改 `root-home-site/`
- 后续真正该改的是模板源码仓库，不是直接手改发布仓库里的 HTML

## 推荐扩展方向

下一批适合继续扩展的页面类型：

- 更多服务器地区页
- 更多中文 AI 工作流页
- 更多越南语本地化页
- 更多数据处理工具页
- 更多电商落地页结构页
- 更多客服 FAQ 场景页

## 维护原则

- 首页不要写成大而空的介绍页，而要持续保持“目录页”定位
- 分类页不要只堆链接，要有本分类的简要判断逻辑
- 子页面要承接具体关键词，不要只换标题
- 工具页优先保证可读、可用和可复制
- 服务页优先保证购买判断逻辑清楚，再做引导
